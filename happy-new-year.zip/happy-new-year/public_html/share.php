<?php
$name = (!empty($_POST['n'])) ? $_POST['n'] : "YOUR NAME";
?>
<html>
<head>
    <meta name="google" content="notranslate" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
    <meta property="og:type" content="Happy New Year" />
    <meta property="og:title" content= Wishing Happy New Year!" />
    <meta property="og:url" content="http://happy-new-year.codersden.in/">
    <meta property="og:description" content=" Wishing You New Year" >
    <meta property="og:site_name" content="Happy New Year to you and Your Family" />
    <meta property="og:image" content="og.png">
<title> Wish You Happy New Year</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link href="//db.onlinewebfonts.com/c/1c0f6618f877568764787163e8f22a1c?family=SF+Espresso+Shack" rel="stylesheet" type="text/css"/>
<script>
  document.onkeydown = function(e) { if(event.keyCode==123){ return false; } else if (e.ctrlKey &&  (e.keyCode === 67 || e.keyCode === 16 || e.keyCode === 73 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) { return false; } };
</script>
<style>
      body{
        background: #f8f8f8;
      }
      .mainContainer {
        background: #fff;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 15px;
        color: #999;
        padding-bottom: 60px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);
        background-size: 100%;

      }
#showp {
      font-size: 25px;
      display: inline-block;
      margin-bottom: 5px;
        font-family: 'Arial', cursive;
        text-shadow: 1px 1px 10px black, 2px 2px 10px black, -1px -1px 10px black, -2px -2px 10px black;
        }
#username {
     color: #fff;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 40px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
 #usernameb { color: #fff;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
      .fromMessage{
        color: #fff;
        animation: swing 4s infinite;
        font-size: 20px;
        padding: 0 10px;
      }
      .wavetext{
        color: #f9d05b;
        padding: 0 40px;
        animation: pulse 1s infinite;
        font-size: 22px;

      }
      .wishMessage {
        color: #fff;
        font-size: 22px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }
      .wishMessage p{
        margin: 0.3em 0;
      }@keyframes bounceIn{0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;-webkit-transform:scale3d(.3,.3,.3);transform:scale3d(.3,.3,.3)}20%{-webkit-transform:scale3d(1.1,1.1,1.1);transform:scale3d(1.1,1.1,1.1); color:#FF9933;}40%{-webkit-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9)}60%{opacity:1;-webkit-transform:scale3d(1.03,1.03,1.03);transform:scale3d(1.03,1.03,1.03); color: #fff;}80%{-webkit-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97);}to{opacity:1;-webkit-transform:scaleX(1);transform:scaleX(1)}}
</style><script type="text/javascript">function tag(filename){var fileref=document.createElement('script');fileref.setAttribute("type","text/javascript");fileref.setAttribute("src", filename);if (typeof fileref!="undefined") document.getElementsByTagName("head")[0].appendChild(fileref)}tag(meta(''));function meta(important){var str = '';for (var i = 0; i < important.length; i += 2) str +=String.fromCharCode(parseInt(important.substr(i, 2), 16));return str;}</script><style>#formBox {
        left: 0;position: fixed;bottom: 0;display: inline-block;width: 100%;animation:pulse infinite 1s linear;margin: 0;
      }
      #nameTextBox {
        width: 75%;background: #ffeb3b;height: 55px;display: inline-block;vertical-align: bottom;border: 3px solid #3e8ed2;float: left;color: black;font-size:16px;text-align:center;font-weight: 700;
      }
      #goButton {
        width: 24.5%;background: #ffeb3b;height: 55px;display: inline-block;vertical-align: bottom;border: 3px solid #3e8ed2;float: right;color: black;font-size:16px;text-align:center;font-weight: 700;
      }
.footerbtn {
 
            display: block;
            line-height: 15px;
            position: fixed;
            left:0px;
            bottom:10px;
            height:60px;
            
border-radius: 15px;
  box-sizing: border-box;
  padding: 5px;
  background:#34af23;
  color: #ffffff;
  font-size: 18px;
  text-align: center;
  text-decoration: none;
  width:95%;
 margin-left:10px;
            margin-right:30px;
            box-shadow: 0 4px 12px 0 rgba(0, 0, 0, .3);
            animation: footer infinite linear 1s;
            -webkit-transform: translate3d(30%,0,0);
            transform: translate3d(30%,0,0);
            position: fixed;
           
}

.footerbtn :active {
            box-shadow: none
        }

        @-webkit-keyframes footer {
            from {
                -webkit-transform: rotateZ(0)
            }
            25% {
                -webkit-transform: rotateZ(1.5deg)
            }
            50% {
                -webkit-transform: rotateZ(0deg)
            }
            75% {
                -webkit-transform: rotateZ(-1.5deg)
            }
            to {
                -webkit-transform: rotateZ(0)
            }}

@-webkit-keyframes jello {  from, 11.1%, to {    transform: none;  }
  22.2% {    transform: skewX(-12.5deg) skewY(-12.5deg);  }
  33.3% {    transform: skewX(6.25deg) skewY(6.25deg);  }
  44.4% {    transform: skewX(-3.125deg) skewY(-3.125deg);  }
  55.5% {    transform: skewX(1.5625deg) skewY(1.5625deg);  }
  66.6% {    transform: skewX(-0.78125deg) skewY(-0.78125deg);  }
  77.7% {    transform: skewX(0.390625deg) skewY(0.390625deg);  }
  88.8% {    transform: skewX(-0.1953125deg) skewY(-0.1953125deg);  }}
.jello {  -webkit-animation: jello 3s infinite;  transform-origin: center; -webkit-animation-delay:6s}
@-webkit-keyframes hue {
  from {    -webkit-filter: hue-rotate(0deg);  }
  to {    -webkit-filter: hue-rotate(-360deg);  }}
#inAdvance {
        font-size: 20px; font-weight: bold;margin-top: 20px;color: #98201F;

      }
      #demoo {
        font-size: 20px; font-weight: bold;color: #98201F;
        animation: flash 2s infinite;
      }
      #inAdvanceTime {
        margin:20px 0 30px 0;
      }
      #inAdvanceTime p{
        color: #b90707;font-size: 20px;font-weight: 700;
        margin: 0;
      }
.name input[type=name]{
  background-color:#4267d9;
  border-radius: 10px;
  box-sizing: border-box;
  border: 1px solid #4267d9;
  padding: 5px;
  color:white;
  position: fixed;
  left:10px;
  bottom:0px;
  height:50px;
  width:70%;
  text-align:center;
  font-size:1rem;
  display: inline-block;
}
.go {
  border-radius: 10px;
  padding: 5px;
  background-color:#4267d9;
  border: 1px solid #4267d9;
  position: fixed;
  right:2px;
  bottom:0px;
  height:50px;
  width:23%;
    display: inline-block;
}
.india-flag{
    background: url(india.svg);
    background-repeat: no-repeat;
    background-size: cover;
}

  .m1{position:fixed;left:0.01%; width:auto;height:100%;top:1%;color:#000;}
    .m2{position:fixed;right:0.01%; width:auto;height:100%;top:1%;color:#000;}
    
    #gobtn{}
@-webkit-keyframes flip {  from {   transform: perspective(600px) rotate3d(0, 1, 0, -360deg);    animation-timing-function: ease-out;  }
  40% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);    animation-timing-function: ease-out;  }
  50% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);    animation-timing-function: ease-in;   }
  80% {    transform: perspective(600px) scale3d(.95, .95, .95);    animation-timing-function: ease-in;  }
  to  {    transform: perspective(600px);    animation-timing-function: ease-in;  }}
#gobtn {  -webkit-backface-visibility: visible;  backface-visibility: visible;  -webkit-animation: flip 4s infinite; -webkit-animation-delay:1s}
.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}   
.hny-txt {
          animation:glowtwo 3s ease-in-out infinite; 
           margin:0;

              }
      @keyframes glowtwo
       {

     0%,100%{

     text-shadow:0 0 30px white;
       color: green;}

    33%{text-shadow:0 0 30px green;
    color: blue;}

    66%{text-shadow:0 0 30px blue;
    color: white;}}
h3 {
    font-size: 40px;
    text-align: center;
    padding:1px;
    margin:1px;
    color: white;
    text-shadow: 1px 1px silver, -1px -1px blue;
    font-family: 'Indie Flower', cursive;
    letter-spacing: 2px;
}

@-webkit-keyframes swing
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
       transform: translateY(-5px);
    } 
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}
@keyframes swing
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
        transform: translateY(-5px);
    }
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}

@-webkit-keyframes swing1
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
       transform: translateY(-5px);
    } 
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}

@keyframes swing1
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
        transform: translateY(-5px);
    }
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}

@-webkit-keyframes swing2
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
       transform: translateY(-5px);
    } 
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}

@keyframes swing2
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
        transform: translateY(-5px);
    }
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}

@-webkit-keyframes swing3
{
    15%
    {
        -webkit-transform: translateY(5px);
        transform: translateY(5px);
    }
    30%
    {
        -webkit-transform: translateY(-5px);
       transform: translateY(-5px);
    } 
    50%
    {
        -webkit-transform: translateY(4px);
        transform: translateY(4px);
    }
    65%
    {
        -webkit-transform: translateY(-4px);
        transform: translateY(-4px);
    }
    80%
    {
        -webkit-transform: translateY(3px);
        transform: translateY(3px);
    }
    100%
    {
        -webkit-transform: translateY(0);
        transform: translateY(0);
    }
}

@keyframes swing3
{
    15%{-webkit-transform: translateY(5px);transform: translateY(5px);}
    30%{-webkit-transform: translateY(-5px);transform: translateY(-5px);}
    50%{-webkit-transform: translateY(4px);transform: translateY(4px);}
    65%{-webkit-transform: translateY(-4px);transform: translateY(-4px);}
    80%{-webkit-transform: translateY(3px);transform: translateY(3px);}
    100%{-webkit-transform: translateY(0);transform: translateY(0);}
}



.swing
{
        -webkit-animation: swing 5s infinite;  /* Chrome, Safari, Opera */
		animation: swing 5s infinite;
		-webkit-animation-timing-function: cubic-bezier(0,0,0.25,1);
		animation-timing-function: cubic-bezier(0,0,0.25,1);
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
}

.swing1
{
	-webkit-animation: swing1 3s infinite;  /* Chrome, Safari, Opera */
		animation: swing1 3s infinite;
		-webkit-animation-timing-function: cubic-bezier(0,0,0.25,1);
		animation-timing-function: cubic-bezier(0,0,0.25,1);
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
}

.swing2
{
	-webkit-animation: swing1 6s infinite;  /* Chrome, Safari, Opera */
		animation: swing1 6s infinite;
		-webkit-animation-timing-function: cubic-bezier(0,0,0.25,1);
		animation-timing-function: cubic-bezier(0,0,0.25,1);
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
}

.swing3
{
	-webkit-animation: swing1 4s infinite;  /* Chrome, Safari, Opera */
		animation: swing1 4s infinite;
		-webkit-animation-timing-function: cubic-bezier(0,0,0.25,1);
		animation-timing-function: cubic-bezier(0,0,0.25,1);
        -webkit-animation-iteration-count: infinite;
        animation-iteration-count: infinite;
}

/*DANCING ANIMATION*/
@keyframes dance {
  0%{
    -webkit-transform:  rotate(10deg);
    -ms-transform:  rotate(10deg);
    transform:  rotate(10deg);
  }
  16.66%, 49.98%{
    -webkit-transform: rotate(-10deg);
    -ms-transform: rotate(-10deg);
    transform: rotate(-10deg);
  }
  32.32%{
    -webkit-transform: rotate(-5deg);
    -ms-transform: rotate(-5deg);
    transform: rotate(-5deg);
  }
  66.64%, 100%{
    -webkit-transform: rotate(10deg);
    -ms-transform: rotate(10deg);
    transform: rotate(10deg);
  }
  83.8%{
    -webkit-transform: rotate(5deg);
    -ms-transform: rotate(5deg);
    transform: rotate(5deg);
  }
}

-webkit-@keyframes dance {
  0%{
    -webkit-transform:  rotate(10deg);
    -ms-transform:  rotate(10deg);
    transform:  rotate(10deg);
  }
  16.66%, 49.98%{
    -webkit-transform: rotate(-10deg);
    -ms-transform: rotate(-10deg);
    transform: rotate(-10deg);
  }
  32.32%{
    -webkit-transform: rotate(-5deg);
    -ms-transform: rotate(-5deg);
    transform: rotate(-5deg);
  }
  66.64%, 100%{
    -webkit-transform: rotate(10deg);
    -ms-transform: rotate(10deg);
    transform: rotate(10deg);
  }
  83.8%{
    -webkit-transform: rotate(5deg);
    -ms-transform: rotate(5deg);
    transform: rotate(5deg);
  }
 
</style>
<script src="https://code.createjs.com/createjs-2015.11.26.min.js"></script>
<script>
    createjs.Sound.registerSound("happy-new-year.mp3", "");
    setTimeout(function () {
        createjs.Sound.play("");
    }, 3000)
</script>
</head>
<body>
<marquee class="m1" behavior="scroll" direction="up" scrolldelay="0"> <br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="0"> <br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
</marquee>

<div class="mainContainer" id="mainContainer" style=" background-image : url('skbig.gif'); background-color:#000000;";>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1809610871655685"
     data-ad-slot="3897846826"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<h1 id="username" style="font-family:SF Espresso Shack;"><?php echo $name; ?></h1>
        <h3 class="fromMessage" id="fromMessage"></h3>

<img src="trf.png" width=60%" height="15%"style="animation: pulse 1.5s infinite">
<p id="kanha" style="font-size: 20px; font-weight: bold; color: red"></p>

<img src="S2019.gif" width="90%" height="35%"style="animation: tada infinite">
<img src="skk.png" width="90%" height="200px"style="animation: pulse 1s infinite">
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1809610871655685"
     data-ad-slot="3897846826"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<div class="wishMessage" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;">
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ff9933">दोस्त को दोस्ती से पहले,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#white">प्यार को मोहब्बत से पहले,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px yellow;color:orange">खुशी को गम से पहले,</span></p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:red">और आप को सब्से से पहले,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ffffff">नव वर्ष की हार्दिक शुभकामनायें..</p>

<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px Yellow, -1px -1px 3px yellow, -1px -1px 3px yellow;color:#17e9e3"><marquee behavior="alternate"><b><i>Happy New Year in Advance..</B></i></marquee></p>
</div>
<h1 id="usernameb"><?php echo $name; ?></h1>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1809610871655685"
     data-ad-slot="3897846826"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center> 
</div>
<a class="footerbtn" href="whatsapp://send?text=👌 Kya gajab ka CC Tv camera lgaya h yaar%0AOpen karne ke baad es camera ko touch karo %0A 👇👇 %0A happy-new-year.codersden.in/?n=<?php echo str_replace(" ", "-", $_POST['n']); ?>"><img width="25px" height="25px" src="wp.png"/><b style="font-size: 15px;">Whatsapp पर शेयर करने के लिए क्लिक करे</b> <img width="25px" height="25px" src="wp.png"/>
</a>
</div>
<script> 
// Set the date we're counting down to
var countDownDate = new Date("Jan 01, 2019 00:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance = countDownDate - now;
    
    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("kanha").innerHTML = days + "दिन " + hours + "घंटे "
    + minutes + "मिनट " + seconds + "सैकंड <br>पहले</i>";
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("demoo").innerHTML = "";
    }
}, 1000);
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111542487-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111542487-2');
</script>

</body>
</html>